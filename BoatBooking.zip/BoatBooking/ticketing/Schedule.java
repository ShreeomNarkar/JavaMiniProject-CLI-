package ticketing;

public class Schedule {
    public static String[] timings = { "5pm to 6pm", "6pm to 7pm", "7pm to 8pm", "8pm to 9pm" };
}
