package ticketing;

public class Boat {
    public String type;
    public int capacity;

    public Boat(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
    }
}
