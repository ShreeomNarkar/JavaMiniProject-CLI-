package ticketing;

public class Customer {
    String name;
    String phone;

    public Customer(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }
}
