package ticketing;

public interface Cancelable {
    void cancelTicket();
}
